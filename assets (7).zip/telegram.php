<?php
$id_telegram = "7029221667";
$id_botTele  = "6425166653:AAFxzcM29Ja_vJmKd2qXWZ0G7-wNMHlIWaM";?>